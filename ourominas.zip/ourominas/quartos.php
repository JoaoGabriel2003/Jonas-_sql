<?php

  include('conexao.php');

  
  if(isset($_POST['submit'])){

    $nome = $_POST['name'];
    $email = $_POST['mail'];
    $telefone = $_POST['tel'];

    $enviar = mysqli_query($conexao, "INSERT INTO reserva VALUES ('$nome','$email','$telefone')");
  };

  $conexao->close();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <link rel="shortcut icon" href="img/bedroom.png" type="image/x-icon">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bedrooms</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }


    body,
    html {
      padding: 20px 0px;
      width: 100%;
      height: 100%;
      background-color: #dddddd;
      background-size: cover;
      overflow-x: hidden;
      font-family: Arial, Helvetica, sans-serif;
      display: grid;
      justify-items: center;

    }


    .header {

      width: 90vw;
      margin: 10px 10px;
      padding: 20px 10px;
      display: flex;
      justify-content: space-around;
      align-items: center;
      background-color: rgb(109, 109, 109);
      border-radius: 10px;
    }


    .logo {
      display: flex;
      align-items: center;
    }

    .logo img {
      margin-right: 20px;
      width: 50px;
      height: 50px;
    }

    .menu {
      display: flex;
      list-style: none;
    }

    .menu a:hover:after {
      opacity: 1;
      left: 0px;
      right: 0px;
      transition: .8s;
    }

    .menu a {
      letter-spacing: 4px;
      font-weight: bolder;
      position: relative;
      color: rgb(0, 0, 0);
      text-transform: capitalize;
      display: inline-block;
      padding: 10px;
      text-decoration: none;
      margin-left: 10px;
    }

    .menu a::after {
      content: "";
      position: absolute;
      height: 4px;
      background-color: #000;
      left: 50%;
      right: 50%;
      bottom: 0;
      opacity: 0;
    }


    .menu a:hover {
      color: #fff;
    }

    .content {
      background-color: rgba(0, 0, 0, 0.2);
      width: 100%;

      border-radius: 10px;
      padding: 30px;
      gap: 20px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      text-align: center;
      position: relative;
      justify-content: center;
      align-content: center;
      align-items: center;
    }



    .line {
      grid-column: 1/-1;
      width: 100%;
      height: 5px;
      background-color: #fff;
    }

    .img img {
      border-radius: 5px;
      border: 2px solid #fff;
      width: 700px;
      height: 500px;
    }

    .about {
      text-align: justify;
      color: #000;
    }

    .quarto {
      margin: 20px 0;
      position: relative;
      text-align: center;
    }

    .quarto::after {
      content: "";
      position: absolute;
      width: 100%;
      height: 5px;
      background-color: #000;
      left: 0;
      bottom: 0;

    }

    .booking {
      height: 100vh;
      width: 100%;
      margin: 50px 0px;
      display: flex;
      justify-content: center;
      flex-direction: column;
      align-items: center;
      gap: 20px;
    }

    .booking form {
      text-align: center;
      gap: 20px;
      display: flex;
      flex-direction: column;
    }

    form input {
      text-align: center;
    }

    .about h1 {
      text-align: center;
      margin: 30px 0px;
    }

    .star {
      color: rgb(251, 255, 0);
      
    }
  </style>
</head>

<body>
  <div class="header">
    <div class="logo">
      <img src="img/icon.png">
      <h1 id="titulo">Hotel Ouro Minas</h1>
    </div>
    <ul class="menu">
      <li class="menu-list"><a href="index.html">Home</a></li>
      <li class="menu-list"><a href="quartos.php">Quartos</a></li>
      <li class="menu-list"><a href="contato.html">Contato</a></li>
      <li class="menu-list"><a href="social.html">Social</a></li>
    </ul>
  </div>
  <h1 class="quarto">Quartos</h1>
  <div class="content">

    <div class="about">
      <h1>Quarto Casal <span class="star">&star; &star; &star;</span></h1>
      <p>Casal inclui: Café da manha, serviço de quarto. piscina liberada e banheira com hidromassagem</p>
    </div>
    <div class="img"> <img src="img/quarto1.jpg" alt=""></div>
    <div class="line"></div>
    <div class="img"> <img src="img/quarto2.jpg" alt=""></div>
    <div class="about">
      <h1>Quarto Master<span class="star"> &star; &star; &star; &star;</span></h1>
      <p> Master inclui: Alimentação em qualquer horario, serviço de quarto, piscina liberada e banheira com hidromassagem</p>
    </div>
    <div class="line"></div>

    <div class="about">
      <h1>Quarto Deluxe <span class="star">&star; &star; &star; &star; &star;</span></h1>
      <p> Deluxe inclui: Alimentação em qualquer horario, serviço de quarto, piscina liberada, banheira com hidromassagem e open bar</p>
    </div>
    <div class="img"> <img src="img/quarto3.jpg" alt=""></div>
  </div>


  <div class="booking">
    <h1>Reserve já</h1>
    <form action="quartos.php" method="post">
      <label for="name">Name: </label>
      <input type="text" name="name" id="name" placeholder="Name">
      <label for="mail">Email: </label>
      <input type="email" name="mail" id="email" placeholder="E-mail">
      <label for="tel">Phone Number: </label>
      <input type="text" name="tel" id="phone" placeholder="telefone">
      <input type="submit" name="submit" values="Enviar">
    </form>
    <h1>Preencha o Formulário e iremos entrar em contato para agendarmos !!!</h1>
  </div>
</body>

</html>