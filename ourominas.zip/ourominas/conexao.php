<?php
    $hostname='localhost';
    $username='root';
    $password='';
    $db='ouro';

    $conexao = new mysqli($hostname,$username,$password,$db);
?>